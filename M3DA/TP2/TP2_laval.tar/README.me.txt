Laval Timoth�e

#############

Le TP est fait jusqu'� la question por cr�er un triangle, le triangle est bien cr�� mais un probl�me avec la gestion des degr�s bloque 
la vision du cercle.

J'ai regard� pour la partie cr�ation de surface mais sans savoir quoi faire.

Ce TP m'a permis de comprendre comment utiliser les game objects du TP1.
