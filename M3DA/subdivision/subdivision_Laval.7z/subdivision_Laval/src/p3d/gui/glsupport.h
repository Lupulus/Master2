#ifndef GLSUPPORT_H
#define GLSUPPORT_H

/*!
*
* @file
*
* @brief
* @author F. Aubert
*
*/

#include <cmath>

#include <iostream>
#ifdef WITH_GLEW
#include <GL/glew.h>
#endif
#include <QGLWidget>



#endif // GLSUPPORT_H

