Laval Timoth�e

Le TP n'est pas fini. Diff�rents bugs que je n'ai pas compris notamment lors de changement de machines comme la m�thode SetSegment qui est appel�e 
malgr� la supression de tous les appels dans le code.

Difficult� personnelle: comprendre la cr�ation des game object et leur instancion entre le code et l'�diteur Unity.