Laval Timothée

###########

Pour faire fonctionner le tp, il faut run la macro avec le dossier images_2016 dans le même dossier.

Une fois le calcul des centres fait, il faut choisir manuellement une nouvelle image via open().

